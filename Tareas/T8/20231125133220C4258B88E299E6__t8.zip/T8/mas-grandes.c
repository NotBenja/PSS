#define _POSIX_C_SOURCE 200809L

#include <stdio.h>
#include <stdarg.h>
#include <sys/types.h>
#include <dirent.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "pss.h"
       
// Defina aca la estructura para guardar nombre y tamanno

// Agregue aca las funciones y variables globales adicionales que necesite

int main(int argc, char *argv[]) {
  // ... complete ...
}
