#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "elim.h"

void eliminar(char *str, char *pat) {
  ...
}

char *eliminados(char *str, char *pat) {
  ...
}
