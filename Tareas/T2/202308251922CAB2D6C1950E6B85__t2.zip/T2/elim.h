void eliminar(char *str, char *pat);
char *eliminados(char *str, char *pat);
