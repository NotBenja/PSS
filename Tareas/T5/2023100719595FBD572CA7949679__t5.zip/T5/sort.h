void sort(char *a[], int n);
